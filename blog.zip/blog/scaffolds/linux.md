---
title: {{ title }}
date: {{ date }}
tags:
- linux
- elementary
categories:
- Linux
- elementary
cover: /img/linux.jpg
---
