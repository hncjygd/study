---
title: {{ title }}
date: {{ date }}
tags:
- linux
- vim
categories:
- Linux
- vim
cover: /img/vim.jpg
---
