---
title: {{ title }}
date: {{ date }}
tags:
- linux
- manjaro
categories:
- Linux
- manjaro
cover: /img/manjaro.png
---
